# Naruto Uzumaki — O Caminho Ninja

Site temático feito com HTML, CSS e JavaScript, usando a imagem enviada.

## Como abrir
1. Extraia o arquivo ZIP.
2. Abra a pasta `site_naruto` no Visual Studio Code.
3. Abra o arquivo `index.html` com a extensão Live Server (ou abra o arquivo diretamente no navegador).

## Estrutura
- `index.html` — conteúdo da página
- `css/style.css` — visual e responsividade
- `js/script.js` — menu para celular
- `img/naruto.png` — imagem enviada

Observação: o site usa uma fonte do Google Fonts; sem internet, será usada uma fonte alternativa.
